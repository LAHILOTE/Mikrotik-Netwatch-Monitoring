import express from 'express';
import { RouterOSAPI } from 'node-routeros';
import path from 'path';
import { WebSocketServer } from 'ws';
import dotenv from 'dotenv';
dotenv.config(); // Load environment variables

console.log('Starting server...');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));

console.log('Express configured.');

// Create global connection
let conn = new RouterOSAPI({
    host: process.env.MIKROTIK_HOST,
    port: process.env.MIKROTIK_PORT,
    user: process.env.MIKROTIK_USER,
    password: process.env.MIKROTIK_PASS,
    timeout: 20000
});

let isConnected = false;

async function fetchMikrotikData() {
    try {
        if (!isConnected) {  // Connect only once
            await conn.connect();
            console.log('✅ Connected to MikroTik');
            isConnected = true;
        }

        const cpuData = await conn.write('/system/resource/print');
        const hotspotData = await conn.write('/ip/hotspot/active/print');
        const pppActiveData = await conn.write('/ppp/active/print');
        const netwatchData = await conn.write('/tool/netwatch/print');

        console.log('🔄 CPU Usage Updated');

        return {
            cpuUsage: cpuData[0]?.['cpu-load'] || '0',
            hotspotOnline: hotspotData.length,
            pppOnline: pppActiveData.length,
            aps: netwatchData.map(nw => ({
                name: nw.comment || '–',
                ip: nw.host || '–',
                status: nw.status === 'up' ? 'ON' : 'OFF'
            }))
        };

    } catch (err) {
        console.error('❌ Error in fetchMikrotikData:', err.message);
        return null;
    }
}

// Start WebSocket server
const wss = new WebSocketServer({ host: '0.0.0.0', port: 8080 });

wss.on('connection', async (ws) => {
    console.log('🌐 Client connected to WebSocket');

    const initialData = await fetchMikrotikData();
    if (initialData) ws.send(JSON.stringify(initialData));

    const interval = setInterval(async () => {
        const data = await fetchMikrotikData();
        if (data) ws.send(JSON.stringify(data));
    }, 15000);

    ws.on('close', async () => {
        console.log('🔴 Client disconnected, closing MikroTik session');
        await conn.close();
        clearInterval(interval);
        isConnected = false;
    });
});

// Route to render the page
app.get('/', async (req, res) => {
    const data = await fetchMikrotikData();
    res.render('index', { data });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
});
