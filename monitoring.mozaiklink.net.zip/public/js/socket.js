const socket = new WebSocket('ws://192.168.4.246:8080');
const escapeHTML = str => str.replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));



socket.onmessage = (event) => {



    const data = JSON.parse(event.data);

    document.getElementById('cpuUsage').innerText = data.cpuUsage + '%';
    document.getElementById('hotspotOnline').innerText = data.hotspotOnline;
    document.getElementById('pppOnline').innerText = data.pppOnline; // ✅ PPP Online Count

    const apOnCount = data.aps.filter(ap => ap.status === 'ON').length;
    const apOffCount = data.aps.filter(ap => ap.status === 'OFF').length;

    document.getElementById('apOn').innerText = apOnCount;
    document.getElementById('apOff').innerText = apOffCount;

    const apList = document.getElementById('apTableBody');
    apList.innerHTML = '';



    data.aps.forEach(ap => {
        const name = escapeHTML(ap.name);
        const ip = escapeHTML(ap.ip);
        apList.innerHTML += `
            <tr>
                <td>${name}</td>
                <td>${ip}</td>
                <td><span class="badge ${ap.status === 'ON' ? 'bg-success' : 'bg-danger'}">${ap.status}</span></td>
            </tr>`;
    });
};
